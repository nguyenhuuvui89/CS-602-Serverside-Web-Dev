function addEmployee(){
    window.location.href = '/employees/add';
}

function cancelAdd(){
    window.location.href = '/employees';
}

function cancelDelete(){
    window.location.href = '/employees';
}

