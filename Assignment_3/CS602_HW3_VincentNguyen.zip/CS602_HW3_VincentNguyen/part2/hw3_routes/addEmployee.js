// Add Employee
module.exports = (req, res, next) => {
  res.render('addEmployeeView', { title: 'Add a New Employee' });
};
